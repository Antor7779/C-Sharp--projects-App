﻿namespace FileExplorerApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            buttonBrowseFolder = new Button();
            buttonSetCustomPath = new Button();
            listBox1 = new ListBox();
            listBox2 = new ListBox();
            listView1 = new ListView();
            imageList1 = new ImageList(components);
            labelFilePath = new Label();
            buttonCopy = new Button();
            SuspendLayout();
            // 
            // buttonBrowseFolder
            // 
            buttonBrowseFolder.Location = new Point(132, 417);
            buttonBrowseFolder.Name = "buttonBrowseFolder";
            buttonBrowseFolder.Size = new Size(112, 34);
            buttonBrowseFolder.TabIndex = 0;
            buttonBrowseFolder.Text = "button1";
            buttonBrowseFolder.UseVisualStyleBackColor = true;
            buttonBrowseFolder.Click += buttonBrowseFolder_Click;
            // 
            // buttonSetCustomPath
            // 
            buttonSetCustomPath.Location = new Point(416, 417);
            buttonSetCustomPath.Name = "buttonSetCustomPath";
            buttonSetCustomPath.Size = new Size(112, 34);
            buttonSetCustomPath.TabIndex = 1;
            buttonSetCustomPath.Text = "Set Path";
            buttonSetCustomPath.UseVisualStyleBackColor = true;
            buttonSetCustomPath.Click += buttonSetCustomPath_Click;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 25;
            listBox1.Location = new Point(64, 37);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(215, 379);
            listBox1.TabIndex = 2;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 25;
            listBox2.Location = new Point(376, 37);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(208, 379);
            listBox2.TabIndex = 3;
            // 
            // listView1
            // 
            listView1.Font = new Font("Segoe UI", 8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            listView1.Location = new Point(590, 12);
            listView1.Name = "listView1";
            listView1.Size = new Size(198, 439);
            listView1.SmallImageList = imageList1;
            listView1.Sorting = SortOrder.Ascending;
            listView1.TabIndex = 4;
            listView1.UseCompatibleStateImageBehavior = false;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth32Bit;
            imageList1.ImageSize = new Size(16, 16);
            imageList1.TransparentColor = Color.Transparent;
            // 
            // labelFilePath
            // 
            labelFilePath.AutoSize = true;
            labelFilePath.Location = new Point(376, 9);
            labelFilePath.Name = "labelFilePath";
            labelFilePath.Size = new Size(59, 25);
            labelFilePath.TabIndex = 5;
            labelFilePath.Text = "label1";
          //  labelFilePath.Click += labelFilePath_Click;
            // 
            // buttonCopy
            // 
            buttonCopy.Location = new Point(592, 466);
            buttonCopy.Name = "buttonCopy";
            buttonCopy.Size = new Size(112, 34);
            buttonCopy.TabIndex = 6;
            buttonCopy.Text = "CopyFile";
            buttonCopy.UseVisualStyleBackColor = true;
            buttonCopy.Click += buttonCopy_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(830, 537);
            Controls.Add(buttonCopy);
            Controls.Add(labelFilePath);
            Controls.Add(listView1);
            Controls.Add(listBox2);
            Controls.Add(listBox1);
            Controls.Add(buttonSetCustomPath);
            Controls.Add(buttonBrowseFolder);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonBrowseFolder;
        private Button buttonSetCustomPath;
        private ListBox listBox1;
        private ListBox listBox2;
        private ListView listView1;
        private ImageList imageList1;
        private Label labelFilePath;
        private Button buttonCopy;
    }
}
